export const URL = 'https://przepisy-e724e-default-rtdb.firebaseio.com/'
export const API_KEY = 'AIzaSyDbE4svENBmu1oY7YUcNn-AqqVtkkdRHkw'

export const SIGN_UP_URL = 'https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=' + API_KEY
export const SIGN_IN_URL = 'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=' + API_KEY
export const RESET_PASSWORD_URL = 'https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=' + API_KEY
export const CHANGE_PASSWORD_URL = 'https://identitytoolkit.googleapis.com/v1/accounts:update?key=' + API_KEY
export const REFRESH_TOKEN_URL = 'https://securetoken.googleapis.com/v1/token?key=' + API_KEY